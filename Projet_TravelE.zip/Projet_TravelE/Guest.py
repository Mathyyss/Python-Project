from dbconnect2 import *
import tkinter
from tkinter import ttk
from tkinter import messagebox
from subprocess import run

class Guest():
    def __init__(self,email):

        self.__guest_email=email

    def getguestemail(self):
        return self.__guest_email

def validate_userid(new_value):

    if ('@hotmail.com' in new_value) or ('@gmail.com' in new_value) or ('@yahoo.com' in new_value):
        return True
    else:
        return False

def myclick(*args):
    print(useremailval.get())
    guest = Guest(useremailval.get())
    print(db.fetch("Select email from guest"))

    value = useridvar.get()
    if not validate_userid(value):
# Si la validation échoue, réinitialisez la saisie à une valeur vide
        useridvar.set("")
        messagebox.showinfo("Error", "Use the correct writing (@hotmail.com; @gmail.com; @yahoo.com")
        return
# Ajoutez un return pour éviter l'exécution du code suivant si la validation échoue

# Boucle pour continuer à demander à l'utilisateur de saisir un identifiant jusqu'à ce qu'il entre une valeur valide
    while not validate_userid(useridvar.get()):
        mainwindow.update_idletasks()  # Met à jour l'interface graphique
        mainwindow.update()

    data = guest.getguestemail()
    db.execute_row("insert into guest(email) values(%s)", data)
    messagebox.showinfo("Important info", "Welcome dear guest")
    run(['python', 'accueil_page.py'])
    mainwindow.destroy()



def go_back():
    run(['python', 'Welcom_page.py'])

db = DBHelper()
db.connection()

mainwindow = tkinter.Tk()
mainwindow.geometry("700x500")
mainwindow['bg'] = "white"

welcomelabel = tkinter.Label(mainwindow, text=" TravelE", font=('Helvetica 18 bold'), pady=10, padx=250)
welcomelabel['bg'] = "crimson"
welcomelabel.pack(anchor=tkinter.CENTER)
welcomevisitor = tkinter.Label(mainwindow, text=" Welcome dear Guest", font=('Helvetica 18 bold'), pady=10, padx=250)
welcomevisitor['bg'] = "white"
welcomevisitor.pack(anchor=tkinter.CENTER)

# Créer une variable de contrôle pour l'Entry
useridvar = tkinter.StringVar()

useremail = tkinter.Label(mainwindow, text="Email", pady=10)
useremail['bg'] = "white"
useremail.pack()
useremailval = tkinter.Entry(text="useremail", width=20, textvariable=useridvar)
useremailval['bg'] = "silver"
useremailval.pack()

# Utilisez la méthode bind pour lier la fonction myclick au clic du bouton
clickme = tkinter.Button(mainwindow, text="connect", command=myclick, bg="Salmon")
clickme.pack()
clickme.bind('<Button-1>', myclick)  # '<Button-1>' représente le clic gauche de la souris

back = tkinter.Button(mainwindow, text="Back up", command=go_back, bg="silver")
back.pack()
mainwindow.mainloop()
# db.disconnect()

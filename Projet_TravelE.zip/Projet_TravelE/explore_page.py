from dbconnect2 import *
import tkinter
from tkinter import ttk
from tkinter import messagebox
from subprocess import run

        #extract the data of from customer,employee or guest table
        #use cookie to know wich table should be display

def open_accueil_page():
    run(['python', 'accueil_page.py'])
def open_Booking_page():
    run(['python', 'booking_page.py'])
def open_explore_page():
    run(['python', 'explore_page.py'])
def open_history_page():
    run(['python', 'History_page.py'])

db=DBHelper()
db.connection()

mainwindow=tkinter.Tk()
mainwindow.geometry("700x500")
mainwindow['bg']="white"


Title=tkinter.Label(mainwindow,text="TravelE",font=('Helvetica 18 bold'),pady=10,padx=250)
Title['bg']="crimson"
Title.pack(anchor=tkinter.CENTER)

Welcome=tkinter.Button(mainwindow, text="welcome", command=open_accueil_page, bg='salmon',relief='raised')
Book=tkinter.Button(mainwindow, text="Booking", command=open_Booking_page, bg='salmon',relief='raised')
Explor=tkinter.Button(mainwindow, text="Explore", command=open_explore_page, bg='silver',relief='raised')
Basket=tkinter.Button(mainwindow, text="Basket", command=open_history_page, bg='salmon',relief='raised')
Welcome.pack(anchor=tkinter.CENTER)
Book.pack(anchor=tkinter.CENTER)
Explor.pack(anchor=tkinter.CENTER)
Basket.pack(anchor=tkinter.CENTER)


SerchDest=tkinter.Label(mainwindow,text="Search destination",pady=10, bg ='white')
SerchDestval=tkinter.Entry(text="destination", width=20, bg = 'white',relief='solid')
SerchDest.pack()
SerchDestval.pack() #dep
Date=tkinter.Label(mainwindow,text="Search Date",pady=10, bg ='white')
DateVal=tkinter.Entry(text="Date", width=20, bg = 'white',relief='solid')
Date.pack()
DateVal.pack()#date
show=tkinter.Button(mainwindow, text="go",bg='grey')
show.pack(side='right')
#afficher TOUT les vols en fonction de la destination et/ou de la date entré dans la bar de recherche

area=tkinter.Label(mainwindow,pady=10)
popularD=tkinter.Label(mainwindow,text=" Available flight",font=('Helvetica 18 bold'),pady=10,padx=250)
popularD['bg']="white"
popularD.pack(anchor=tkinter.CENTER)

#If connexion costumer/guest show Available flight only
#If connexion employee show all the flight of entry
#Use data file for this


mainwindow.mainloop()
from dbconnect2 import *
import tkinter
from tkinter import ttk
from tkinter import messagebox
from subprocess import run
class customer():
    def __init__(self,name,tel,email,code):

        self.__cust_name=name
        self.__cust_tel=tel
        self.__cust_email=email
        self.__cust_code=code


    def getcustname(self):
        return self.__cust_name
    def getcustTel(self):
        return self.__cust_tel
    def getcustemail(self):
        return self.__cust_email
    def getcustcode(self):
        return self.__cust_code

def validate_mail(mail):
    if ('@hotmail.com' in mail) or ('@gmail.com' in mail) or ('@yahoo.com' in mail):
        return True
    else:
        messagebox.showinfo("Error", "Use the correct writing (@hotmail.com; @gmail.com; @yahoo.com")
        return False

def validate_tel(tel):
    if len(tel)!=10:
        #don't forget numerical condition!
        messagebox.showinfo("Error", "This is not a valide phone number")
        return False
    else:
        return True

def validate_password(password):
    if len(password)<8:
        messagebox.showinfo("Error", "The password should have at less 8 caracteres")
        return False
    else:
        return True


def sign_up(*args):
    cust=customer(unameval.get(),usertelval.get(),useremailval.get(),usercodeval.get())
    value=usertelvar.get()
    valmail=usermailvar.get()
    valcode=usercodevar.get()

    if (not validate_tel(value) or not validate_mail(valmail) or not validate_password(valcode)):
        if (not validate_mail(valmail) or not validate_password(valcode) or not validate_tel(value)):
            if (not validate_password(valcode) or not validate_tel(value) or not validate_mail(valmail)):
                usertelvar.set("")
                usermailvar.set("")
                usercodevar.set("")
# Si la validation échoue, réinitialisez la saisie à une valeur vide
                return
    while not validate_tel(value) or not validate_mail(valmail) or not validate_password(valcode):
        mainwindow.update_idletasks()  # Met à jour l'interface graphique
        mainwindow.update()

    data=(cust.getcustname(),cust.getcustTel(),cust.getcustemail(),cust.getcustcode())
    data0=cust.getcustname()
    data1=cust.getcustTel()
    data2=cust.getcustemail()
    data3=cust.getcustcode()
    query=f"Select * FROM customer WHERE name='{data0}' AND tel='{data1}' AND email='{data2}' AND password='{data3}'"
    db_cust=db.fetch(query)
    if db_cust :
        messagebox.showinfo("Important", "This ID already exist in our database !")

    else :
        db.execute_row("insert into customer(name,tel,email,password) values(%s,%s,%s,%s)",data)
        messagebox.showinfo("Important info","Data insreted successfully")
        mainwindow.destroy()



def log_in():

    cust=customer(unameval.get(),usertelval.get(),useremailval.get(),usercodeval.get())
    data0=cust.getcustname()
    data1=cust.getcustTel()
    data2=cust.getcustemail()
    data3=cust.getcustcode()
    query=f"Select * FROM customer WHERE name='{data0}' AND tel='{data1}' AND email='{data2}' AND password='{data3}'"
    db_cust=db.fetch(query)

    if db_cust :
        messagebox.showinfo("Important", "Welcome dear member!")
        run(['python', 'accueil_page.py'])
        mainwindow.destroy()


    else :
        messagebox.showinfo("Important info","You are not in our database")




def go_back():
    run(['python','Welcom_page.py'])
    mainwindow.destroy()

db=DBHelper()
db.connection()

mainwindow=tkinter.Tk()
mainwindow.geometry("700x500")
mainwindow['bg']="white"

welcomelabel=tkinter.Label(mainwindow,text=" TravelE",font=('Helvetica 18 bold'),pady=10,padx=250)
welcomelabel['bg']="crimson"
welcomelabel.pack(anchor=tkinter.CENTER)
welcomevisitor=tkinter.Label(mainwindow,text=" Welcome dear member",font=('Helvetica 18 bold'),pady=10,padx=250)
welcomevisitor['bg']="white"
welcomevisitor.pack(anchor=tkinter.CENTER)



username=tkinter.Label(mainwindow,text="User Name",pady=10)
username['bg']="white"
username.pack()
unameval=tkinter.Entry(text="uname",width=20)
unameval['bg']="silver"
unameval.pack()
# Créer une variable de contrôle pour l'Entry
usertelvar = tkinter.StringVar()  #contrôle tel
usertel=tkinter.Label(mainwindow,text="Phone number",pady=10)
usertel['bg']="white"
usertel.pack()
usertelval=tkinter.Entry(text="usertel",width=20,textvariable=usertelvar)
usertelval['bg']="silver"
usertelval.pack()

usermailvar=tkinter.StringVar() #control mail
useremail=tkinter.Label(mainwindow,text="Email",pady=10)
useremail['bg']="white"
useremail.pack()
useremailval=tkinter.Entry(text="useremail",width=20, textvariable=usermailvar)
useremailval['bg']="silver"
useremailval.pack()

usercodevar=tkinter.StringVar()#control password
usercode=tkinter.Label(mainwindow,text="Password",pady=10)
usercode['bg']="white"
usercode.pack()
usercodeval=tkinter.Entry(text="usercode",width=20,textvariable=usercodevar)
usercodeval['bg']="silver"
usercodeval.pack()

clickme=tkinter.Button(mainwindow,text="Sign up",command=sign_up,bg="Salmon")
clickme.pack()
clickme.bind('<Button-1>', sign_up)
log=tkinter.Button(mainwindow, text='Log in', command=log_in, bg="Salmon")
log.pack()
Back=tkinter.Button(mainwindow,text="Back up",command=go_back,bg="Salmon")
Back.pack()
mainwindow.mainloop()
#db.disconnect()

#if error about the fiel doesn't exist show
#  >> import os
#  >> os.chdir('C:\\Users\\Ilian\\Pytoon_course\\Projet_TravelE')
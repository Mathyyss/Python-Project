from dbconnect2 import *
import tkinter
from tkinter import ttk
from tkinter import messagebox
from subprocess import run

def open_customer_page():

    run(['python', 'customer.py'])
    mainwindow.destroy()
def open_guest_page():
    run(['python','Guest.py'])
    mainwindow.destroy()
def open_employee_page():
    run(['python', 'Employe.py'])
    mainwindow.destroy()

db=DBHelper()
db.connection()

mainwindow=tkinter.Tk()
mainwindow.geometry("700x500")
mainwindow['bg']="white"

welcomelabel=tkinter.Label(mainwindow,text=" TravelE",font=('Helvetica 18 bold'),pady=10,padx=250)
welcomelabel['bg']="crimson"
welcomelabel.pack(anchor=tkinter.CENTER)


area=tkinter.Label(mainwindow,text="     ",pady=30,padx=250)
area['bg']="white"
area.pack()

Member=tkinter.Button(mainwindow,text="MEMBER",command=open_customer_page,pady=30,padx=250,bg="Salmon")
Member.pack()
area1=tkinter.Label(mainwindow,pady=10,padx=250)
area1['bg']="white"
area1.pack()
Guest=tkinter.Button(mainwindow,text="GUEST",command=open_guest_page,pady=30,padx=250,bg="Salmon")
Guest.pack()
area2=tkinter.Label(mainwindow,pady=10,padx=250)
area2['bg']="white"
area2.pack()
Employee=tkinter.Button(mainwindow,text="EMPLOYEE",command=open_employee_page,pady=30,padx=250,bg="Salmon")
Employee.pack()

mainwindow.mainloop()

#save the ID of the customer or employe in a file and read it when you need to keep customer info #Do a deconnexion button and erase the content of the file


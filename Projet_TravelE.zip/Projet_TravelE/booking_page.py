from dbconnect2 import *
import tkinter
from tkinter import ttk
from tkinter import messagebox
from subprocess import run

        #extract the data of from customer,employee or guest table
        #use cookie to know wich table should be display

def open_accueil_page():
    run(['python', 'accueil_page.py'])
def open_Booking_page():
    run(['python', 'booking_page.py'])
def open_explore_page():
    run(['python', 'explore_page.py'])
def open_history_page():
    run(['python', 'History_page.py'])

db=DBHelper()
db.connection()

mainwindow=tkinter.Tk()
mainwindow.geometry("700x500")
mainwindow['bg']="white"


Title=tkinter.Label(mainwindow,text="TravelE",font=('Helvetica 18 bold'),pady=10,padx=250)
Title['bg']="crimson"
Title.pack(anchor=tkinter.CENTER)

Welcome=tkinter.Button(mainwindow, text="welcome", command=open_accueil_page, bg='salmon',relief='raised')
Book=tkinter.Button(mainwindow, text="Booking", command=open_Booking_page, bg='silver',relief='raised')
Explor=tkinter.Button(mainwindow, text="Explore", command=open_explore_page, bg='salmon',relief='raised')
Basket=tkinter.Button(mainwindow, text="Basket", command=open_history_page, bg='salmon',relief='raised')
Welcome.pack(anchor=tkinter.CENTER)
Book.pack(anchor=tkinter.CENTER)
Explor.pack(anchor=tkinter.CENTER)
Basket.pack(anchor=tkinter.CENTER)
#Add the option command in each button DON'T FORGET!!

flightDep=tkinter.Label(mainwindow,text="Departure airport",pady=10, bg ='white')
flightDepval=tkinter.Entry(text="Depart", width=20, bg = 'silver')
flightDep.pack()
flightDepval.pack() #dep
ArrivalDate=tkinter.Label(mainwindow,text="Arrival Date",pady=10, bg ='white')
ArrivalDateVal=tkinter.Entry(text="Arrival", width=20, bg = 'silver')
ArrivalDate.pack()
ArrivalDateVal.pack()#arrive
ReturnDate=tkinter.Label(mainwindow,text="Returning Date",pady=10, bg ='white')
ReturnDateVal=tkinter.Entry(text="Return", width=20, bg = 'silver')
ReturnDate.pack()
ReturnDateVal.pack()#return
Passenger=tkinter.Label(mainwindow,text="Passenger",pady=10, bg ='white')
PassengerVal=tkinter.Entry(text="Passenger", width=20, bg = 'silver')
Passenger.pack()
PassengerVal.pack()#Passenger
Class=tkinter.Label(mainwindow,text="Class",pady=10, bg ='white')
Classval=tkinter.Entry(text="Passenger", width=20, bg = 'silver')
Class.pack()
Classval.pack()#class
edit=tkinter.Button(mainwindow, text="go",bg='grey')
edit.pack(side='right')
#don't forget contraint in each entry



area=tkinter.Label(mainwindow,pady=10)
popularD=tkinter.Label(mainwindow,text=" Available flight",font=('Helvetica 18 bold'),pady=10,padx=250)
popularD['bg']="white"
popularD.pack(anchor=tkinter.CENTER)

#afficher les vols en funtion des valeurs entrées dans les bar de recherche. Quand une ligne est selectionner le vol a prendre en function
#Faire en sorte de pouvoir reservé plusieurs siège en une fois ou just ajouter chaque siège en plusieur fois




mainwindow.mainloop()
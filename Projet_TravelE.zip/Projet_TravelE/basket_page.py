from dbconnect2 import *
import tkinter
from tkinter import ttk
from tkinter import messagebox
from subprocess import run

        #extract the data of from customer,employee or guest table
        #use cookie to know wich table should be display

def open_accueil_page():
    run(['python', 'accueil_page.py'])
def open_Booking_page():
    run(['python', 'booking_page.py'])
def open_explore_page():
    run(['python', 'explore_page.py'])
def open_history_page():
    run(['python', 'History_page.py'])

db=DBHelper()
db.connection()

mainwindow=tkinter.Tk()
mainwindow.geometry("700x500")
mainwindow['bg']="white"


Title=tkinter.Label(mainwindow,text="TravelE",font=('Helvetica 18 bold'),pady=10,padx=250)
Title['bg']="crimson"
Title.pack(anchor=tkinter.CENTER)

Welcome=tkinter.Button(mainwindow, text="welcome", command=open_accueil_page, bg='salmon',relief='raised')
Book=tkinter.Button(mainwindow, text="Booking", command=open_Booking_page, bg='salmon',relief='raised')
Explor=tkinter.Button(mainwindow, text="Explore", command=open_explore_page, bg='salmon',relief='raised')
Basket=tkinter.Button(mainwindow, text="Basket", command=open_history_page, bg='silver',relief='raised')
Welcome.pack(anchor=tkinter.CENTER)
Book.pack(anchor=tkinter.CENTER)
Explor.pack(anchor=tkinter.CENTER)
Basket.pack(anchor=tkinter.CENTER)


basket=tkinter.Label(mainwindow,text="Basket ",pady=10, bg ='white')
basket.pack()
#Show ticket data enregistré dans la partie booking
area=tkinter.Label(mainwindow,pady=40)

bill=tkinter.Button(mainwindow, text="sale",bg='grey')
bill.pack()
#When you click on this button, show card info and click another time to buy ticket
cancel=tkinter.Button(mainwindow, text="cancel",bg='grey')
cancel.pack()


mainwindow.mainloop()
from dbconnect2 import *
import tkinter
from tkinter import ttk
from tkinter import messagebox
from subprocess import run

        #extract the data of from customer,employee or guest table
        #use cookie to know wich table should be display

def open_accueil_page():
    run(['python', 'accueil_page.py'])
def open_Booking_page():
    run(['python', 'booking_page.py'])
def open_explore_page():
    run(['python', 'explore_page.py'])
def open_history_page():
    run(['python', 'History_page.py'])

db=DBHelper()
db.connection()

mainwindow=tkinter.Tk()
mainwindow.geometry("700x500")
mainwindow['bg']="white"


Title=tkinter.Label(mainwindow,text="TravelE",font=('Helvetica 18 bold'),pady=10,padx=250)
Title['bg']="crimson"
Title.grid(row=0, column=0, columnspan=4, pady=10)

Welcome=tkinter.Button(mainwindow, text="welcome", command=open_accueil_page, bg='salmon',relief='raised')
Book=tkinter.Button(mainwindow, text="Booking", command=open_Booking_page, bg='salmon',relief='raised')
Explor=tkinter.Button(mainwindow, text="Explore", command=open_explore_page, bg='salmon',relief='raised')
Basket=tkinter.Button(mainwindow, text="Basket", command=open_history_page, bg='silver',relief='raised')
Welcome.grid(row=1, column=0, padx=10)
Book.grid(row=1, column=1, padx=10)
Explor.grid(row=1, column=2, padx=10)
Basket.grid(row=1, column=3, padx=10)


history=tkinter.Label(mainwindow,text="Flight number ", bg ='white')
historyVal=tkinter.Entry(text="Flight number", width=20, bg = 'white',relief='solid')
history.grid()
historyVal.grid() #history
show=tkinter.Button(mainwindow, text="go",bg='grey')
show.grid(row=5, column=1)
#show THE flight that the customer has already buy with ID_customer
all=tkinter.Button(mainwindow, text="see all",bg='grey')
all.grid(row=5, column=2, padx=1)
#show ALL the flight that the customer has already buy with ID_customer


area=tkinter.Label(mainwindow,pady=10)
popularD=tkinter.Label(mainwindow,text=" History",font=('Helvetica 18 bold'),pady=10,padx=250)
popularD['bg']="white"
popularD.grid(row=6, column=1, padx=1)


mainwindow.mainloop()
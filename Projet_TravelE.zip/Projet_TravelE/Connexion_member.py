import tkinter

mainwindow=tkinter.Tk()
mainwindow.geometry("500x300")
mainwindow['bg']="light purple"

welcomelabel=tkinter.Label(mainwindow,text="TravelE",font=('Helvetica 18 bold'))
welcomelabel.pack(anchor=tkinter.CENTER)
userid=tkinter.Label(mainwindow,text="User Id",pady=10)
userid.pack()
useridval=tkinter.Entry(text="userid",width=20)
useridval.pack()
username=tkinter.Label(mainwindow,text="User Name",pady=10)
username.pack()
unameval=tkinter.Entry(text="uname",width=20)
unameval.pack()
clickme=tkinter.Button(mainwindow,text="Save",bg="green")
clickme.pack()
viewdata=tkinter.Button(mainwindow,text="View records")
viewdata.pack()
mainwindow.mainloop()
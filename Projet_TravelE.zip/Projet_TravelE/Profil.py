from dbconnect2 import *
import tkinter
from tkinter import Tk, Label, Listbox, Scrollbar, StringVar, Entry, Button, END
from tkinter import ttk
from tkinter import messagebox
from subprocess import run

        #extract the data of from customer,employee or guest table
        #use cookie to know wich table should be display
class Profil():
    def __init__(self,Fname, Lname, email, numEmp):
        self.__prof_Fname=Fname
        self.__prof_Lname=Lname
        self.__prof_email=email
        self.__prof_numEmp=numEmp

def afficher_resultats():
    # Récupérer le mail de utilisateur dans un fichier
    ligne_id = 'ANA'
    # Requête avec un paramètre
    query = f"SELECT * FROM customer WHERE name = '{ligne_id}'"
    # Utiliser un curseur pour exécuter la requête avec le paramètre
    result = db.fetch(query)
    # Effacer le contenu actuel de la listebox
    listebox.delete(0, END)
    # Afficher les résultats dans la listebox
    for row in result:
        for key, value in row.items():
            listebox.insert(END, f"{key}: {value}")


db=DBHelper()
db.connection()

mainwindow=tkinter.Tk()
mainwindow.geometry("700x500")
mainwindow['bg']="white"


Title=tkinter.Label(mainwindow,text="TravelE",font=('Helvetica 18 bold'),pady=10,padx=250)
Title['bg']="crimson"
Title.pack(anchor=tkinter.CENTER)

Welcome=tkinter.Button(mainwindow, text="welcome",bg='salmon',relief='raised')
Book=tkinter.Button(mainwindow, text="Booking",bg='salmon',relief='raised')
Explor=tkinter.Button(mainwindow, text="Explore",bg='salmon',relief='raised')
Basket=tkinter.Button(mainwindow, text="Basket",bg='salmon',relief='raised')
Welcome.pack()
Book.pack()
Explor.pack()
Basket.pack()



#afficher le profile du membre ou de l'employé
listebox =tkinter.Listbox(mainwindow, font=('Helvetica 14 bold'), width=65, bg="white")
listebox.pack(pady=10)

# Barre de défilement pour la listebox
scrollbar =tkinter.Scrollbar(mainwindow, orient="vertical")
scrollbar.pack(side="right", fill="y")
listebox.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=listebox.yview)


edit=tkinter.Button(mainwindow, text="edit",bg='grey')
edit.pack(side='bottom')
#boutton qui permet de suprrimer son compte. page redirigé vers l'entrée alors et opération encours annulée
back=tkinter.Button(mainwindow, text="Profil", command=afficher_resultats, bg='grey')
back.pack(side='bottom')

mainwindow.mainloop()
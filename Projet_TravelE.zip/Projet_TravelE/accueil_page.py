from dbconnect2 import *
import tkinter
from tkinter import ttk
from tkinter import messagebox
from subprocess import run

        #extract the data of from customer,employee or guest table
        #use cookie to know wich table should be display

def open_accueil_page():
    run(['python', 'accueil_page.py'])
def open_Booking_page():
    run(['python', 'booking_page.py'])
def open_explore_page():
    run(['python', 'explore_page.py'])
def open_history_page():
    run(['python', 'History_page.py'])

db=DBHelper()
db.connection()

mainwindow=tkinter.Tk()
mainwindow.geometry("700x500")
mainwindow['bg']="white"


Title=tkinter.Label(mainwindow,text="TravelE",font=('Helvetica 18 bold'),pady=10,padx=250)
Title['bg']="crimson"
Title.grid()

Welcome=tkinter.Button(mainwindow, text="welcome", command=open_accueil_page, bg='silver',relief='raised')
Book=tkinter.Button(mainwindow, text="Booking", command=open_Booking_page, bg='salmon',relief='raised')
Explor=tkinter.Button(mainwindow, text="Explore", command=open_explore_page, bg='salmon',relief='raised')
Basket=tkinter.Button(mainwindow, text="Basket", command=open_history_page, bg='salmon',relief='raised')
Welcome.grid(row=1, column=0,padx=5)
Book.grid(row=1, column=1,padx=5)
Explor.grid(row=1, column=1,padx=5)
Basket.grid(row=1, column=3,padx=5)


welcomepage=tkinter.Label(mainwindow,text=" Offers",font=('Helvetica 18 bold'),pady=10,padx=250)
welcomepage['bg']="white"
welcomepage.grid()
#afficher les offres ajouter par l'employée. Crée une table offre. Les valeur doivent être ajouté afin de correspondre au prie des billets

area=tkinter.Label(mainwindow,pady=30)
popularD=tkinter.Label(mainwindow,text=" Popular",font=('Helvetica 18 bold'),pady=10,padx=250)
popularD['bg']="white"
popularD.grid()
#calculer et afficher les vols des destinations les plus vendues


mainwindow.mainloop()
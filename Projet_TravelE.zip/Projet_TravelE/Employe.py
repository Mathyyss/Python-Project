from dbconnect2 import *
import tkinter
from tkinter import ttk
from tkinter import messagebox
from subprocess import run
class Employee():
    def __init__(self,Fname,Lname,numE,Eemail):

        self.__Emp_Fname=Fname
        self.__Emp_Lname=Lname
        self.__Emp_numE=numE
        self.__Emp_email=Eemail



    def getEmpFname(self):
        return self.__Emp_Fname
    def getEmpLname(self):
        return self.__Emp_Lname
    def getEmpnumE(self):
        return self.__Emp_numE
    def getEmpEemail(self):
        return self.__Emp_email


def myclick(*args):

    Emp=Employee(userFnameval.get(),userLnameval.get(),usernumEval.get(),useremailval.get())
    data=Emp.getEmpFname()
    data1=Emp.getEmpLname()
    data2=Emp.getEmpnumE()
    data3=Emp.getEmpEemail()

    query = f"SELECT * FROM employee WHERE first_name = '{data}' AND last_name ='{data1}' AND num_employee='{data2}' AND Eemail='{data3}'"
    db_emp = db.fetch(query)

    if db_emp:
        messagebox.showinfo("Information", "Welcome employee")
        run(['python', 'accueil_page.py'])
        mainwindow.destroy()
    else :
        messagebox.showinfo("Information", "You are not in our database")


def go_back():
    run(['python','Welcom_page.py'])
    mainwindow.destroy()


db=DBHelper()
db.connection()

mainwindow=tkinter.Tk()
mainwindow.geometry("700x500")
mainwindow['bg']="white"

welcomelabel=tkinter.Label(mainwindow,text=" TravelE",font=('Helvetica 18 bold'),pady=10,padx=250)
welcomelabel['bg']="crimson"
welcomelabel.pack(anchor=tkinter.CENTER)
welcomevisitor=tkinter.Label(mainwindow,text=" Welcome dear employee",font=('Helvetica 18 bold'),pady=10,padx=250)
welcomevisitor['bg']="white"
welcomevisitor.pack(anchor=tkinter.CENTER)

userFname=tkinter.Label(mainwindow,text="First name", pady=10)
userFname['bg']="white"
userFname.pack()
userFnameval=tkinter.Entry(text="userFname",width=20)
userFnameval['bg']="silver"
userFnameval.pack()

userLname=tkinter.Label(mainwindow,text="Last name", pady=10)
userLname['bg']="white"
userLname.pack()
userLnameval=tkinter.Entry(text="userLname",width=20)
userLnameval['bg']="silver"
userLnameval.pack()

usernumE=tkinter.Label(mainwindow,text="numE",pady=10)
usernumE['bg']="white"
usernumE.pack()
usernumEval=tkinter.Entry(text="usernumE",width=20)
usernumEval['bg']="silver"
usernumEval.pack()

useremail=tkinter.Label(mainwindow,text="Email",pady=10)
useremail['bg']="white"
useremail.pack()
useremailval=tkinter.Entry(text="useremail",width=20)
useremailval['bg']="silver"
useremailval.pack()


clickme=tkinter.Button(mainwindow,text="connect",command=myclick,bg="Salmon")
clickme.pack()
back=tkinter.Button(mainwindow,text="Back up",command=go_back,bg="silver")
back.pack()
mainwindow.mainloop()
#db.disconnect()

from dbconnect2 import *
import tkinter
from tkinter import ttk
from tkinter import messagebox

        #extract the data of from customer,employee or guest table
        #use cookie to know wich table should be display

db=DBHelper()
db.connection()

mainwindow=tkinter.Tk()
mainwindow.geometry("700x500")
mainwindow['bg']="white"


Title=tkinter.Label(mainwindow,text="TravelE",font=('Helvetica 18 bold'),pady=10,padx=250)
Title['bg']="crimson"
Title.pack(anchor=tkinter.CENTER)

Welcome=tkinter.Button(mainwindow, text="welcome",bg='salmon',relief='raised')
Book=tkinter.Button(mainwindow, text="Reserved",bg='silver',relief='raised')
Explor=tkinter.Button(mainwindow, text="Explore",bg='salmon',relief='raised')
Basket=tkinter.Button(mainwindow, text="Basket",bg='salmon',relief='raised')
Welcome.pack(anchor=tkinter.CENTER)
Book.pack(anchor=tkinter.CENTER)
Explor.pack(anchor=tkinter.CENTER)
Basket.pack(anchor=tkinter.CENTER)
#Add the option command in each button DON'T FORGET!!

flightDep=tkinter.Label(mainwindow,text="Departure airport",pady=10, bg ='white')
flightDepval=tkinter.Entry(text="Depart", width=20, bg = 'silver')
flightDep.pack()
flightDepval.pack() #dep
ArrivalDate=tkinter.Label(mainwindow,text="Arrival Date",pady=10, bg ='white')
ArrivalDateVal=tkinter.Entry(text="Arrival", width=20, bg = 'silver')
ArrivalDate.pack()
ArrivalDateVal.pack()#arrive
ReturnDate=tkinter.Label(mainwindow,text="Returning Date",pady=10, bg ='white')
ReturnDateVal=tkinter.Entry(text="Return", width=20, bg = 'silver')
ReturnDate.pack()
ReturnDateVal.pack()#return
Discount=tkinter.Label(mainwindow,text="Discount",pady=10, bg ='white')
Discountval=tkinter.Entry(text="Discount", width=20, bg = 'silver')
Discount.pack()
Discountval.pack()#Discount
Cost=tkinter.Label(mainwindow,text="Class",pady=10, bg ='white')
Costval=tkinter.Entry(text="Cost", width=20, bg = 'silver')
Cost.pack()
Costval.pack()#class
show=tkinter.Button(mainwindow, text="go",bg='grey')
show.pack(side='right')


area=tkinter.Label(mainwindow,pady=10)
popularD=tkinter.Label(mainwindow,text=" Available flight",font=('Helvetica 18 bold'),pady=10,padx=250)
popularD['bg']="white"
popularD.pack(anchor=tkinter.CENTER)

#Show/print the data from flight table




mainwindow.mainloop()